What is it?
Always On Top is a free Windows utility that will help you keep any window in the foreground.

How to use?
Launch the utility, select a window and then press the Ctrl+Space shortcut to stick that window in the front. 

Contact?
web: http://www.labnol.org/
twitter: http://twitter.com/labnol